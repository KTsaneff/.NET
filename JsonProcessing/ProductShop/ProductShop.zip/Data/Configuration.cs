﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=localhost, 1433;Database=ProductShop;User Id=sa;Password=JEAlousy01;";
    }
}
