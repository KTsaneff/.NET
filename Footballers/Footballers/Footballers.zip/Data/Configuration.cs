﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost, 1433;Database=Footballers;User ID=sa;Password=JEAlousy01;Trusted_Connection=False";
    }
}
