﻿namespace Trucks.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost, 1433;Database=Trucks;User ID=sa;Password=JEAlousy01;Trusted_Connection=False";
    }
}